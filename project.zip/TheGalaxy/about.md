# The Galaxy

A floating galaxy ball. Tap it to open the Galaxy menu. Drag the ball or the menu anywhere.

**Global:** Speedhack, Show FPS, FPS Bypass
**Player:** Noclip
**Audio:** Audio Sync (music/sfx pitch follows your speed)
**Cosmetics:** Unlock All Cosmetics, Diamonds tool

Tap the **i** next to any feature to see what it does.

Notes: everything is local to your device. Using speedhack/noclip can stop levels counting on leaderboards, and the in-game diamonds count is also uploaded with your profile score, so inflated diamonds can get an account flagged. The 1% "caught" roll in the Diamonds tool is only a game event inside the mod - the real risk is not 1%.
