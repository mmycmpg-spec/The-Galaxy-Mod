# The Galaxy

A floating galaxy ball. Tap it to open the Galaxy menu. Drag the ball or the menu anywhere. Use the - and + buttons at the top of the menu to resize it.

**Global:** Speedhack, FPS Bypass, Show FPS
**Player:** Noclip, No Death Effect, No Camera Shake
**Build:** Toggle Grid, Copy Level Data (backup your level)
**Audio:** Audio Sync (pitch follows your speed)
**Style:** 7 menu themes, 10 main-menu backgrounds (incl. Rainbow), ball size, ball in level on/off
**Shop:** Unlock All Cosmetics, Diamonds tool

The ball and menu work in menus, levels and the editor, and there is also a Galaxy button in the pause menu. Tap the **i** next to any feature to see what it does.

Notes: everything is local to your device. Using speedhack/noclip can stop levels counting on leaderboards, and the in-game diamonds count is also uploaded with your profile score, so inflated diamonds can get an account flagged. The 1% "caught" roll in the Diamonds tool is only a game event inside the mod - the real risk is not 1%.
