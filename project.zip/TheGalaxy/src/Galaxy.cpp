#include "Galaxy.hpp"
#include <Geode/ui/OverlayManager.hpp>
#include <algorithm>
#include <climits>
#include <cmath>
#include <Geode/ui/Notification.hpp>
#include <random>

namespace {
    galaxy::State g_state;
    GalaxyMenu* g_menu = nullptr;
    GalaxyBall* g_ball = nullptr;

    bool g_savedOriginalFps = false;
    float g_origFps = 60.f;
    float g_lastPitch = 1.f;

    enum Feature { F_SPEED = 1, F_SHOWFPS, F_FPS, F_NOCLIP, F_AUDIO, F_UNLOCK };

    char const* featureInfo(int id) {
        switch (id) {
            case F_SPEED:
                return "Speedhack\n\nMakes the whole game run faster or slower. 1.00x is normal. "
                       "Use + and - to change it (0.1x to 10x).";
            case F_SHOWFPS:
                return "Show FPS\n\nShows the game's FPS counter in the corner of the screen.";
            case F_FPS:
                return "FPS Bypass\n\nSets the game's FPS target (30 to 1000). Higher is only smoother "
                       "if your device can keep up - if it stutters, lower it.";
            case F_NOCLIP:
                return "Noclip\n\nYou don't die when you hit things in a level. "
                       "Levels finished with noclip may not count on leaderboards.";
            case F_AUDIO:
                return "Audio Sync\n\nMakes music and sound effects change pitch with your Speedhack "
                       "speed, so the audio stays in sync with the game. Needs Speedhack on.";
            case F_UNLOCK:
                return "Unlock All Cosmetics\n\nShows every icon and color as unlocked so you can pick "
                       "them. This is local to your device.";
        }
        return "";
    }

    float speedStep(float v, int dir) {
        v = std::round((v + dir * 0.1f) * 100.f) / 100.f;
        return std::clamp(v, 0.1f, 10.f);
    }
}

// ================================================================
// State / effects
// ================================================================

galaxy::State& galaxy::state() { return g_state; }

void galaxy::load() {
    auto* m = Mod::get();
    g_state.speedOn = m->getSavedValue<bool>("speed-on", false);
    g_state.speed = m->getSavedValue<float>("speed", 1.f);
    g_state.audioSync = m->getSavedValue<bool>("audio-sync", false);
    g_state.fpsOn = m->getSavedValue<bool>("fps-on", false);
    g_state.fps = m->getSavedValue<int>("fps", 60);
    g_state.showFps = m->getSavedValue<bool>("show-fps", false);
    g_state.noclip = m->getSavedValue<bool>("noclip", false);
    g_state.unlockAll = m->getSavedValue<bool>("unlock-all", false);
    g_state.speed = std::clamp(g_state.speed, 0.1f, 10.f);
    g_state.fps = std::clamp(g_state.fps, 30, 1000);
}

void galaxy::save() {
    auto* m = Mod::get();
    m->setSavedValue<bool>("speed-on", g_state.speedOn);
    m->setSavedValue<float>("speed", g_state.speed);
    m->setSavedValue<bool>("audio-sync", g_state.audioSync);
    m->setSavedValue<bool>("fps-on", g_state.fpsOn);
    m->setSavedValue<int>("fps", g_state.fps);
    m->setSavedValue<bool>("show-fps", g_state.showFps);
    m->setSavedValue<bool>("noclip", g_state.noclip);
    m->setSavedValue<bool>("unlock-all", g_state.unlockAll);
}

void galaxy::apply() {
    auto* dir = CCDirector::sharedDirector();
    if (!dir) return;

    // Speedhack
    dir->getScheduler()->setTimeScale(g_state.speedOn ? g_state.speed : 1.f);

    // FPS bypass
    if (auto* gm = GameManager::sharedState()) {
        if (!g_savedOriginalFps) {
            g_savedOriginalFps = true;
            g_origFps = gm->m_customFPSTarget >= 1.f ? gm->m_customFPSTarget : 60.f;
        }
        float fps = g_state.fpsOn ? static_cast<float>(g_state.fps) : g_origFps;
        gm->m_customFPSTarget = fps;
        gm->updateCustomFPS();
        dir->setAnimationInterval(1.0 / static_cast<double>(fps));
    }

    dir->setDisplayStats(g_state.showFps);
}

void galaxy::tickAudio() {
    auto* fmod = FMODAudioEngine::sharedEngine();
    if (!fmod) return;

    bool sync = g_state.audioSync && g_state.speedOn;
    float pitch = sync ? g_state.speed : 1.f;
    if (!sync && g_lastPitch == 1.f) return; // nothing to undo

    if (fmod->m_backgroundMusicChannel) fmod->m_backgroundMusicChannel->setPitch(pitch);
    if (fmod->m_globalChannel) fmod->m_globalChannel->setPitch(pitch);
    g_lastPitch = pitch;
}

void galaxy::addDiamonds(int amount) {
    if (amount <= 0) return;

    if (g_state.diamondsLocked) {
        FLAlertLayer::create("Locked",
            "The diamonds tool is locked for this session because you got caught.\n"
            "Restart the game to unlock it.", "OK")->show();
        return;
    }

    // 1% chance of the "caught" game event
    static std::mt19937 rng{std::random_device{}()};
    if (std::uniform_int_distribution<int>(1, 100)(rng) == 1) {
        g_state.diamondsLocked = true;
        FLAlertLayer::create("CAUGHT!",
            "<cr>You got caught diamond hacking!</c>\n\n"
            "That was the 1% event: no diamonds were added and the diamonds tool is locked "
            "until you restart the game.\n\n"
            "(This is only a game inside the mod. Real accounts can still be flagged for "
            "inflated stats, and that risk is not 1%.)", "OK")->show();
        return;
    }

    auto* gsm = GameStatsManager::sharedState();
    if (!gsm) return;
    long long total = static_cast<long long>(gsm->getStat("13")) + amount;
    total = std::min<long long>(total, 2000000000LL);
    gsm->setStat("13", static_cast<int>(total));
    Notification::create("Added " + std::to_string(amount) + " diamonds", NotificationIcon::Success)->show();
}

// ================================================================
// Ball
// ================================================================

void galaxy::ensureBall() {
    if (g_ball) return;
    g_ball = GalaxyBall::create();
    if (!g_ball) return;
    OverlayManager::get()->addChild(g_ball, 1000);
}

GalaxyBall* GalaxyBall::create() {
    auto ret = new GalaxyBall();
    if (ret && ret->init()) {
        ret->autorelease();
        return ret;
    }
    delete ret;
    return nullptr;
}

bool GalaxyBall::init() {
    if (!CCLayer::init()) return false;

    this->setContentSize({52, 52});
    this->ignoreAnchorPointForPosition(false);
    this->setAnchorPoint({0.5f, 0.5f});

    this->setTouchMode(kCCTouchesOneByOne);
    this->setTouchPriority(-127);
    this->setTouchEnabled(true);

    CCSprite* icon = CCSprite::create("galaxy_icon.png"_spr);
    if (!icon) icon = CCSprite::createWithSpriteFrameName("GJ_moonsIcon_001.png");
    if (icon) {
        icon->setScale(48.f / std::max(icon->getContentSize().height, 1.f));
        icon->setPosition({26, 26});
        icon->runAction(CCRepeatForever::create(CCRotateBy::create(12.f, 360.f)));
        this->addChild(icon);
    }

    auto winSize = CCDirector::sharedDirector()->getWinSize();
    float x = Mod::get()->getSavedValue<float>("ball-x", winSize.width - 40.f);
    float y = Mod::get()->getSavedValue<float>("ball-y", winSize.height / 2);
    this->setPosition({std::clamp(x, 26.f, winSize.width - 26.f), std::clamp(y, 26.f, winSize.height - 26.f)});

    this->schedule(schedule_selector(GalaxyBall::tick), 0.25f);
    return true;
}

void GalaxyBall::tick(float) {
    galaxy::tickAudio();
}

bool GalaxyBall::ccTouchBegan(CCTouch* touch, CCEvent*) {
    if (!getParent()) return false;
    auto p = getParent()->convertToNodeSpace(touch->getLocation());
    auto c = getPosition();
    float dx = p.x - c.x, dy = p.y - c.y;
    if (dx * dx + dy * dy > 30.f * 30.f) return false;
    m_touching = true;
    m_moved = false;
    m_start = p;
    return true;
}

void GalaxyBall::ccTouchMoved(CCTouch* touch, CCEvent*) {
    if (!m_touching || !getParent()) return;
    auto now = getParent()->convertToNodeSpace(touch->getLocation());
    auto prev = getParent()->convertToNodeSpace(touch->getPreviousLocation());
    float dx = now.x - m_start.x, dy = now.y - m_start.y;
    if (dx * dx + dy * dy > 64.f) m_moved = true;
    if (!m_moved) return;
    auto winSize = CCDirector::sharedDirector()->getWinSize();
    auto pos = getPosition() + (now - prev);
    pos.x = std::clamp(pos.x, 26.f, winSize.width - 26.f);
    pos.y = std::clamp(pos.y, 26.f, winSize.height - 26.f);
    setPosition(pos);
}

void GalaxyBall::ccTouchEnded(CCTouch*, CCEvent*) {
    if (!m_touching) return;
    m_touching = false;
    if (m_moved) {
        Mod::get()->setSavedValue<float>("ball-x", getPositionX());
        Mod::get()->setSavedValue<float>("ball-y", getPositionY());
        return;
    }
    // a tap: open or close the menu
    if (auto* menu = GalaxyMenu::current()) {
        menu->removeFromParentAndCleanup(true);
    } else if (auto* m = GalaxyMenu::create()) {
        OverlayManager::get()->addChild(m, 999);
    }
}

void GalaxyBall::ccTouchCancelled(CCTouch* t, CCEvent* e) { ccTouchEnded(t, e); }

// ================================================================
// Menu
// ================================================================

GalaxyMenu* GalaxyMenu::current() { return g_menu; }

GalaxyMenu* GalaxyMenu::create() {
    auto ret = new GalaxyMenu();
    if (ret && ret->init()) {
        ret->autorelease();
        return ret;
    }
    delete ret;
    return nullptr;
}

GalaxyMenu::~GalaxyMenu() {
    if (g_menu == this) g_menu = nullptr;
}

bool GalaxyMenu::init() {
    if (!CCLayer::init()) return false;
    g_menu = this;

    this->setContentSize({kW, kH});
    this->setTouchMode(kCCTouchesOneByOne);
    this->setTouchPriority(-127); // just behind the buttons
    this->setTouchEnabled(true);

    auto winSize = CCDirector::sharedDirector()->getWinSize();
    float x = Mod::get()->getSavedValue<float>("menu-x", winSize.width / 2 - kW / 2);
    float y = Mod::get()->getSavedValue<float>("menu-y", winSize.height / 2 - kH / 2);
    this->setPosition({x, y});
    this->setScale(0.9f);

    auto* bg = CCScale9Sprite::create("GJ_square02.png");
    bg->setContentSize({kW, kH});
    bg->setPosition({kW / 2, kH / 2});
    bg->setOpacity(240);
    bg->setColor({40, 30, 90});
    this->addChild(bg);

    auto* title = CCLabelBMFont::create("THE GALAXY", "goldFont.fnt");
    title->setScale(0.7f);
    title->setPosition({kW / 2, kH - 18});
    this->addChild(title);

    auto* menu = CCMenu::create();
    menu->setPosition({0, 0});
    this->addChild(menu, 5);

    // close
    auto* closeSpr = CCSprite::createWithSpriteFrameName("GJ_closeBtn_001.png");
    closeSpr->setScale(0.6f);
    auto* closeBtn = CCMenuItemSpriteExtra::create(closeSpr, this, menu_selector(GalaxyMenu::onClose));
    closeBtn->setPosition({kW - 14, kH - 14});
    menu->addChild(closeBtn);

    // tabs
    char const* names[4] = {"Global", "Player", "Audio", "Cosmetics"};
    float xs[4] = {42, 112, 172, 242};
    for (int i = 0; i < 4; i++) {
        auto* spr = ButtonSprite::create(names[i], "bigFont.fnt", "GJ_button_04.png", 0.45f);
        auto* btn = CCMenuItemSpriteExtra::create(spr, this, menu_selector(GalaxyMenu::onTab));
        btn->setTag(i);
        btn->setPosition({xs[i], kH - 48});
        menu->addChild(btn);
    }

    m_content = CCNode::create();
    this->addChild(m_content, 4);
    buildTab();
    return true;
}

void GalaxyMenu::onClose(CCObject*) {
    this->removeFromParentAndCleanup(true);
}

void GalaxyMenu::onTab(CCObject* sender) {
    m_tab = static_cast<CCNode*>(sender)->getTag();
    buildTab();
}

void GalaxyMenu::addToggleRow(char const* name, int featureId, bool value, float y) {
    auto* menu = CCMenu::create();
    menu->setPosition({0, 0});
    m_content->addChild(menu);

    auto* label = CCLabelBMFont::create(name, "bigFont.fnt");
    label->setAnchorPoint({0, 0.5f});
    label->setScale(0.45f);
    label->setPosition({20, y});
    m_content->addChild(label);

    auto* toggle = CCMenuItemToggler::createWithStandardSprites(
        this, menu_selector(GalaxyMenu::onToggle), 0.55f);
    toggle->toggle(value);
    toggle->setTag(featureId);
    toggle->setPosition({kW - 70, y});
    menu->addChild(toggle);

    auto* infoSpr = CCSprite::createWithSpriteFrameName("GJ_infoIcon_001.png");
    infoSpr->setScale(0.6f);
    auto* infoBtn = CCMenuItemSpriteExtra::create(infoSpr, this, menu_selector(GalaxyMenu::onInfo));
    infoBtn->setTag(featureId);
    infoBtn->setPosition({kW - 30, y});
    menu->addChild(infoBtn);
}

void GalaxyMenu::buildTab() {
    m_content->removeAllChildrenWithCleanup(true);
    m_speedLabel = m_fpsLabel = m_diamondLabel = nullptr;
    m_amountInput = nullptr;

    auto& s = galaxy::state();
    float top = kH - 85;

    if (m_tab == 0) { // Global
        addToggleRow("Speedhack", F_SPEED, s.speedOn, top);

        auto* menu = CCMenu::create();
        menu->setPosition({0, 0});
        m_content->addChild(menu);
        m_speedLabel = CCLabelBMFont::create("", "goldFont.fnt");
        m_speedLabel->setScale(0.5f);
        m_speedLabel->setPosition({kW / 2, top - 26});
        m_content->addChild(m_speedLabel);
        for (int i = 0; i < 2; i++) {
            auto* spr = ButtonSprite::create(i == 0 ? "-" : "+", "goldFont.fnt", "GJ_button_01.png", 0.6f);
            auto* btn = CCMenuItemSpriteExtra::create(spr, this, menu_selector(GalaxyMenu::onSpeedStep));
            btn->setTag(i == 0 ? -1 : 1);
            btn->setPosition({kW / 2 + (i == 0 ? -80.f : 80.f), top - 26});
            menu->addChild(btn);
        }

        addToggleRow("FPS Bypass", F_FPS, s.fpsOn, top - 58);
        m_fpsLabel = CCLabelBMFont::create("", "goldFont.fnt");
        m_fpsLabel->setScale(0.5f);
        m_fpsLabel->setPosition({kW / 2, top - 84});
        m_content->addChild(m_fpsLabel);
        for (int i = 0; i < 2; i++) {
            auto* spr = ButtonSprite::create(i == 0 ? "-" : "+", "goldFont.fnt", "GJ_button_01.png", 0.6f);
            auto* btn = CCMenuItemSpriteExtra::create(spr, this, menu_selector(GalaxyMenu::onFpsStep));
            btn->setTag(i == 0 ? -1 : 1);
            btn->setPosition({kW / 2 + (i == 0 ? -80.f : 80.f), top - 84});
            menu->addChild(btn);
        }

        addToggleRow("Show FPS", F_SHOWFPS, s.showFps, top - 116);

        m_speedLabel->setString(fmt::format("Speed: {:.2f}x", s.speed).c_str());
        m_fpsLabel->setString(fmt::format("FPS: {}", s.fps).c_str());
    } else if (m_tab == 1) { // Player
        addToggleRow("Noclip", F_NOCLIP, s.noclip, top);
        auto* note = CCLabelBMFont::create("More player features coming soon", "chatFont.fnt");
        note->setScale(0.45f);
        note->setPosition({kW / 2, top - 40});
        m_content->addChild(note);
    } else if (m_tab == 2) { // Audio
        addToggleRow("Audio Sync", F_AUDIO, s.audioSync, top);
        auto* note = CCLabelBMFont::create("Works together with Speedhack", "chatFont.fnt");
        note->setScale(0.45f);
        note->setPosition({kW / 2, top - 40});
        m_content->addChild(note);
    } else { // Cosmetics
        addToggleRow("Unlock All", F_UNLOCK, s.unlockAll, top);

        m_diamondLabel = CCLabelBMFont::create("", "goldFont.fnt");
        m_diamondLabel->setScale(0.55f);
        m_diamondLabel->setPosition({kW / 2, top - 30});
        m_content->addChild(m_diamondLabel);

        auto* menu = CCMenu::create();
        menu->setPosition({0, 0});
        m_content->addChild(menu);

        int amounts[3] = {100, 1000, 10000};
        for (int i = 0; i < 3; i++) {
            auto* spr = ButtonSprite::create(("+" + std::to_string(amounts[i])).c_str(),
                                             "goldFont.fnt", "GJ_button_01.png", 0.55f);
            auto* btn = CCMenuItemSpriteExtra::create(spr, this, menu_selector(GalaxyMenu::onAddDiamonds));
            btn->setTag(amounts[i]);
            btn->setPosition({kW / 2 - 85.f + i * 85.f, top - 62});
            menu->addChild(btn);
        }

        m_amountInput = geode::TextInput::create(110, "Any amount", "bigFont.fnt");
        m_amountInput->setCommonFilter(geode::CommonFilter::Uint);
        m_amountInput->setMaxCharCount(9);
        m_amountInput->setScale(0.8f);
        m_amountInput->setPosition({kW / 2 - 40, top - 98});
        m_content->addChild(m_amountInput);

        auto* addSpr = ButtonSprite::create("Add", "goldFont.fnt", "GJ_button_02.png", 0.55f);
        auto* addBtn = CCMenuItemSpriteExtra::create(addSpr, this, menu_selector(GalaxyMenu::onAddCustom));
        addBtn->setPosition({kW / 2 + 60, top - 98});
        menu->addChild(addBtn);

        auto* warn = CCLabelBMFont::create("1% chance you get caught!", "chatFont.fnt");
        warn->setScale(0.45f);
        warn->setColor({255, 120, 120});
        warn->setPosition({kW / 2, top - 124});
        m_content->addChild(warn);

        refreshDiamonds();
    }
}

void GalaxyMenu::refreshDiamonds() {
    if (!m_diamondLabel) return;
    int have = 0;
    if (auto* gsm = GameStatsManager::sharedState()) have = gsm->getStat("13");
    m_diamondLabel->setString(fmt::format("Diamonds: {}", have).c_str());
}

void GalaxyMenu::onToggle(CCObject* sender) {
    auto* toggle = static_cast<CCMenuItemToggler*>(sender);
    bool nowOn = !toggle->isToggled(); // the toggler flips after the callback
    auto& s = galaxy::state();
    switch (toggle->getTag()) {
        case F_SPEED: s.speedOn = nowOn; break;
        case F_SHOWFPS: s.showFps = nowOn; break;
        case F_FPS: s.fpsOn = nowOn; break;
        case F_NOCLIP: s.noclip = nowOn; break;
        case F_AUDIO: s.audioSync = nowOn; break;
        case F_UNLOCK: s.unlockAll = nowOn; break;
    }
    galaxy::save();
    galaxy::apply();
}

void GalaxyMenu::onInfo(CCObject* sender) {
    int id = static_cast<CCNode*>(sender)->getTag();
    FLAlertLayer::create("Info", featureInfo(id), "OK")->show();
}

void GalaxyMenu::onSpeedStep(CCObject* sender) {
    auto& s = galaxy::state();
    s.speed = speedStep(s.speed, static_cast<CCNode*>(sender)->getTag());
    if (m_speedLabel) m_speedLabel->setString(fmt::format("Speed: {:.2f}x", s.speed).c_str());
    galaxy::save();
    galaxy::apply();
}

void GalaxyMenu::onFpsStep(CCObject* sender) {
    auto& s = galaxy::state();
    s.fps = std::clamp(s.fps + 30 * static_cast<CCNode*>(sender)->getTag(), 30, 1000);
    if (m_fpsLabel) m_fpsLabel->setString(fmt::format("FPS: {}", s.fps).c_str());
    galaxy::save();
    galaxy::apply();
}

void GalaxyMenu::onAddDiamonds(CCObject* sender) {
    galaxy::addDiamonds(static_cast<CCNode*>(sender)->getTag());
    refreshDiamonds();
}

void GalaxyMenu::onAddCustom(CCObject*) {
    if (!m_amountInput) return;
    std::string text = m_amountInput->getString();
    if (text.empty()) {
        Notification::create("Type an amount first", NotificationIcon::Warning)->show();
        return;
    }
    long long amount = 0;
    try { amount = std::stoll(text); } catch (...) { amount = 0; }
    amount = std::min<long long>(amount, 1000000000LL);
    galaxy::addDiamonds(static_cast<int>(amount));
    refreshDiamonds();
}

// ---- dragging the menu ---------------------------------------

bool GalaxyMenu::ccTouchBegan(CCTouch* touch, CCEvent*) {
    auto local = this->convertToNodeSpace(touch->getLocation());
    m_dragging = CCRect(0, 0, kW, kH).containsPoint(local);
    return m_dragging;
}

void GalaxyMenu::ccTouchMoved(CCTouch* touch, CCEvent*) {
    if (!m_dragging || !getParent()) return;
    auto now = getParent()->convertToNodeSpace(touch->getLocation());
    auto prev = getParent()->convertToNodeSpace(touch->getPreviousLocation());
    setPosition(getPosition() + (now - prev));
}

void GalaxyMenu::ccTouchEnded(CCTouch*, CCEvent*) {
    if (!m_dragging) return;
    m_dragging = false;
    Mod::get()->setSavedValue<float>("menu-x", getPositionX());
    Mod::get()->setSavedValue<float>("menu-y", getPositionY());
}

void GalaxyMenu::ccTouchCancelled(CCTouch* t, CCEvent* e) { ccTouchEnded(t, e); }
