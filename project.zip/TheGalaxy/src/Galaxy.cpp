#include "Galaxy.hpp"
#include "BallIcon.hpp"
#include <Geode/ui/OverlayManager.hpp>
#include <Geode/ui/Notification.hpp>
#include <algorithm>
#include <climits>
#include <cmath>
#include <random>

namespace {
    galaxy::State g_state;
    GalaxyMenu* g_menu = nullptr;
    GalaxyBall* g_ball = nullptr;

    bool g_savedOriginalFps = false;
    float g_origFps = 60.f;
    float g_lastPitch = 1.f;
    bool g_haveOrigBg = false;
    ccColor3B g_origBg = {255, 255, 255};

    enum Feature {
        F_SPEED = 1, F_SHOWFPS, F_FPS, F_NOCLIP, F_AUDIO, F_UNLOCK,
        F_NODEATH, F_NOSHAKE, F_BALLLEVEL
    };

    struct Theme { char const* name; ccColor3B panel; ccColor3B accent; };
    Theme const kThemes[] = {
        {"Galaxy Purple", {45, 30, 100}, {255, 220, 90}},
        {"Deep Ocean",    {20, 55, 110}, {120, 225, 255}},
        {"Emerald",       {15, 80, 55},  {150, 255, 175}},
        {"Crimson",       {100, 20, 35}, {255, 160, 160}},
        {"Sunset",        {115, 55, 20}, {255, 205, 110}},
        {"Midnight",      {18, 18, 32},  {200, 200, 255}},
        {"Rose",          {105, 30, 85}, {255, 175, 230}},
    };
    constexpr int kThemeCount = sizeof(kThemes) / sizeof(kThemes[0]);

    struct Bg { char const* name; ccColor3B color; };
    Bg const kBgs[] = {
        {"Default",  {255, 255, 255}},
        {"Purple",   {95, 45, 210}},
        {"Ocean",    {30, 95, 225}},
        {"Emerald",  {30, 175, 115}},
        {"Crimson",  {205, 40, 65}},
        {"Sunset",   {255, 135, 45}},
        {"Gold",     {235, 195, 45}},
        {"Pink",     {240, 85, 175}},
        {"Dark",     {28, 28, 45}},
        {"Rainbow",  {255, 255, 255}},
    };
    constexpr int kBgCount = sizeof(kBgs) / sizeof(kBgs[0]);

    char const* featureInfo(int id) {
        switch (id) {
            case F_SPEED:
                return "Speedhack\n\nMakes the whole game run faster or slower. 1.00x is normal. "
                       "Use + and - to change it (0.1x to 10x).";
            case F_SHOWFPS:
                return "Show FPS\n\nShows the game's FPS counter in the corner of the screen.";
            case F_FPS:
                return "FPS Bypass\n\nSets the game's FPS target (30 to 1000). Most phone screens "
                       "cap at 60/90/120 FPS, so numbers above your screen's refresh rate may "
                       "not look any different. If it stutters, lower it.";
            case F_NOCLIP:
                return "Noclip\n\nYou don't die when you hit things in a level. "
                       "Levels finished with noclip may not count on leaderboards.";
            case F_AUDIO:
                return "Audio Sync\n\nMakes music and sound effects change pitch with your Speedhack "
                       "speed, so the audio stays in sync with the game. Needs Speedhack on.";
            case F_UNLOCK:
                return "Unlock All Cosmetics\n\nShows every icon and color as unlocked so you can pick "
                       "them. This is local to your device.";
            case F_NODEATH:
                return "No Death Effect\n\nSkips the explosion animation when you die, so you "
                       "respawn with less lag and less distraction.";
            case F_NOSHAKE:
                return "No Camera Shake\n\nStops the screen from shaking in levels.";
            case F_BALLLEVEL:
                return "Ball In Level\n\nShows the floating ball while you play or edit a level. "
                       "If it is off, open the Galaxy from the Pause menu instead.";
        }
        return "";
    }

    CCSprite* makeBallSprite() {
        static CCTexture2D* tex = nullptr;
        if (!tex) {
            auto* img = new CCImage();
            if (img->initWithImageData(const_cast<unsigned char*>(kBallIcon), sizeof(kBallIcon))) {
                auto* t = new CCTexture2D();
                if (t->initWithImage(img)) tex = t; else t->release();
            }
            img->release();
        }
        return tex ? CCSprite::createWithTexture(tex) : nullptr;
    }

    bool inLevel() {
        return PlayLayer::get() != nullptr || LevelEditorLayer::get() != nullptr;
    }
}

// ================================================================
// State / effects
// ================================================================

galaxy::State& galaxy::state() { return g_state; }
int galaxy::themeCount() { return kThemeCount; }
char const* galaxy::themeName(int i) { return kThemes[std::clamp(i, 0, kThemeCount - 1)].name; }
int galaxy::backgroundCount() { return kBgCount; }
char const* galaxy::backgroundName(int i) { return kBgs[std::clamp(i, 0, kBgCount - 1)].name; }

void galaxy::load() {
    auto* m = Mod::get();
    auto& s = g_state;
    s.speedOn = m->getSavedValue<bool>("speed-on", false);
    s.speed = m->getSavedValue<float>("speed", 1.f);
    s.audioSync = m->getSavedValue<bool>("audio-sync", false);
    s.fpsOn = m->getSavedValue<bool>("fps-on", false);
    s.fps = m->getSavedValue<int>("fps", 60);
    s.showFps = m->getSavedValue<bool>("show-fps", false);
    s.noclip = m->getSavedValue<bool>("noclip", false);
    s.noDeathEffect = m->getSavedValue<bool>("no-death-effect", false);
    s.noShake = m->getSavedValue<bool>("no-shake", false);
    s.unlockAll = m->getSavedValue<bool>("unlock-all", false);
    s.ballInLevel = m->getSavedValue<bool>("ball-in-level", true);
    s.theme = m->getSavedValue<int>("theme", 0);
    s.background = m->getSavedValue<int>("background", 0);
    s.ballScale = m->getSavedValue<float>("ball-scale", 1.f);
    s.menuScale = m->getSavedValue<float>("menu-scale", 0.85f);
    s.speed = std::clamp(s.speed, 0.1f, 10.f);
    s.fps = std::clamp(s.fps, 30, 1000);
    s.theme = std::clamp(s.theme, 0, kThemeCount - 1);
    s.background = std::clamp(s.background, 0, kBgCount - 1);
    s.ballScale = std::clamp(s.ballScale, 0.6f, 2.0f);
    s.menuScale = std::clamp(s.menuScale, 0.5f, 1.4f);
}

void galaxy::save() {
    auto* m = Mod::get();
    auto& s = g_state;
    m->setSavedValue<bool>("speed-on", s.speedOn);
    m->setSavedValue<float>("speed", s.speed);
    m->setSavedValue<bool>("audio-sync", s.audioSync);
    m->setSavedValue<bool>("fps-on", s.fpsOn);
    m->setSavedValue<int>("fps", s.fps);
    m->setSavedValue<bool>("show-fps", s.showFps);
    m->setSavedValue<bool>("noclip", s.noclip);
    m->setSavedValue<bool>("no-death-effect", s.noDeathEffect);
    m->setSavedValue<bool>("no-shake", s.noShake);
    m->setSavedValue<bool>("unlock-all", s.unlockAll);
    m->setSavedValue<bool>("ball-in-level", s.ballInLevel);
    m->setSavedValue<int>("theme", s.theme);
    m->setSavedValue<int>("background", s.background);
    m->setSavedValue<float>("ball-scale", s.ballScale);
    m->setSavedValue<float>("menu-scale", s.menuScale);
}

void galaxy::apply() {
    auto* dir = CCDirector::sharedDirector();
    if (!dir) return;

    // Speedhack. Inside a level the game controls the time scale itself (time warp),
    // so we go through it; outside a level we set it directly.
    if (auto* pl = PlayLayer::get()) {
        pl->applyTimeWarp(pl->m_gameState.m_timeWarp);
    } else {
        dir->getScheduler()->setTimeScale(g_state.speedOn ? g_state.speed : 1.f);
    }

    // FPS bypass
    if (auto* gm = GameManager::sharedState()) {
        if (!g_savedOriginalFps) {
            g_savedOriginalFps = true;
            g_origFps = gm->m_customFPSTarget >= 1.f ? gm->m_customFPSTarget : 60.f;
        }
        float fps = g_state.fpsOn ? static_cast<float>(g_state.fps) : g_origFps;
        gm->m_customFPSTarget = fps;
        gm->updateCustomFPS();
        dir->setAnimationInterval(1.0 / static_cast<double>(fps));
    }

    dir->setDisplayStats(g_state.showFps);
}

void galaxy::applyBackground() {
    auto* scene = CCDirector::sharedDirector()->getRunningScene();
    if (!scene) return;
    auto* node = scene->getChildByIDRecursive("main-menu-bg");
    auto* bg = typeinfo_cast<CCSprite*>(node);
    if (!bg) return;

    if (!g_haveOrigBg) {
        g_haveOrigBg = true;
        g_origBg = bg->getColor();
    }
    bg->stopAllActions();

    int i = g_state.background;
    if (i == 0) {
        bg->setColor(g_origBg);
    } else if (i == kBgCount - 1) { // Rainbow
        bg->setColor({255, 60, 60});
        bg->runAction(CCRepeatForever::create(CCSequence::create(
            CCTintTo::create(1.5f, 255, 200, 40),
            CCTintTo::create(1.5f, 60, 220, 90),
            CCTintTo::create(1.5f, 50, 160, 255),
            CCTintTo::create(1.5f, 190, 80, 255),
            CCTintTo::create(1.5f, 255, 60, 60),
            nullptr)));
    } else {
        bg->setColor(kBgs[i].color);
    }
}

void galaxy::tick() {
    // keep FPS applied (the game likes to reset it when you change screens)
    if (g_state.fpsOn) {
        if (auto* dir = CCDirector::sharedDirector()) {
            dir->setAnimationInterval(1.0 / static_cast<double>(g_state.fps));
        }
    }

    // outside levels the game never resets the time scale, but make sure of it
    if (!PlayLayer::get() && !LevelEditorLayer::get()) {
        if (auto* dir = CCDirector::sharedDirector()) {
            dir->getScheduler()->setTimeScale(g_state.speedOn ? g_state.speed : 1.f);
        }
    }

    // keep music/sfx pitch equal to the REAL game speed, so audio stays in sync
    if (auto* fmod = FMODAudioEngine::sharedEngine()) {
        bool sync = g_state.audioSync && g_state.speedOn;
        float scale = CCDirector::sharedDirector()->getScheduler()->getTimeScale();
        float pitch = sync ? std::clamp(scale, 0.1f, 10.f) : 1.f;
        if (sync || g_lastPitch != 1.f) {
            if (fmod->m_backgroundMusicChannel) fmod->m_backgroundMusicChannel->setPitch(pitch);
            if (fmod->m_globalChannel) fmod->m_globalChannel->setPitch(pitch);
            FMOD::ChannelGroup* master = nullptr;
            if (fmod->m_system && fmod->m_system->getMasterChannelGroup(&master) == FMOD_OK && master) {
                master->setPitch(1.f); // make sure nothing else stacks on top
            }
            g_lastPitch = pitch;
        }
    }
}

void galaxy::addDiamonds(int amount) {
    if (amount <= 0) return;

    if (g_state.diamondsLocked) {
        FLAlertLayer::create("Locked",
            "The diamonds tool is locked for this session because you got caught.\n"
            "Restart the game to unlock it.", "OK")->show();
        return;
    }

    // 1% chance of the "caught" game event
    static std::mt19937 rng{std::random_device{}()};
    if (std::uniform_int_distribution<int>(1, 100)(rng) == 1) {
        g_state.diamondsLocked = true;
        FLAlertLayer::create("CAUGHT!",
            "<cr>You got caught diamond hacking!</c>\n\n"
            "That was the 1% event: no diamonds were added and the diamonds tool is locked "
            "until you restart the game.\n\n"
            "(This is only a game inside the mod. Real accounts can still be flagged for "
            "inflated stats, and that risk is not 1%.)", "OK")->show();
        return;
    }

    auto* gsm = GameStatsManager::sharedState();
    if (!gsm) return;
    long long total = static_cast<long long>(gsm->getStat("13")) + amount;
    total = std::min<long long>(total, 2000000000LL);
    gsm->setStat("13", static_cast<int>(total));
    Notification::create("Added " + std::to_string(amount) + " diamonds", NotificationIcon::Success)->show();
}

void galaxy::toggleMenu() {
    if (auto* menu = GalaxyMenu::current()) {
        menu->removeFromParentAndCleanup(true);
    } else if (auto* m = GalaxyMenu::create()) {
        OverlayManager::get()->addChild(m, 999);
    }
}

// ================================================================
// Ball
// ================================================================

void galaxy::ensureBall() {
    if (g_ball) return;
    g_ball = GalaxyBall::create();
    if (!g_ball) return;
    OverlayManager::get()->addChild(g_ball, 1000);
}

GalaxyBall* GalaxyBall::create() {
    auto ret = new GalaxyBall();
    if (ret && ret->init()) {
        ret->autorelease();
        return ret;
    }
    delete ret;
    return nullptr;
}

bool GalaxyBall::init() {
    if (!CCLayer::init()) return false;

    this->setContentSize({52, 52});
    this->ignoreAnchorPointForPosition(false);
    this->setAnchorPoint({0.5f, 0.5f});

    this->setTouchMode(kCCTouchesOneByOne);
    this->setTouchPriority(-127);
    this->setTouchEnabled(true);

    m_icon = CCNode::create();
    m_icon->setPosition({26, 26});
    this->addChild(m_icon);

    CCSprite* icon = makeBallSprite();
    if (icon) {
        icon->setScale(48.f / std::max(icon->getContentSize().height, 1.f));
        icon->runAction(CCRepeatForever::create(CCRotateBy::create(14.f, 360.f)));
        m_icon->addChild(icon);
    } else {
        // last resort: a plain gold star made from text, never a missing texture
        auto* star = CCLabelBMFont::create("*", "goldFont.fnt");
        star->setScale(2.f);
        m_icon->addChild(star);
    }
    // gentle pulse
    m_icon->runAction(CCRepeatForever::create(CCSequence::create(
        CCScaleTo::create(1.2f, 1.06f), CCScaleTo::create(1.2f, 0.96f), nullptr)));

    auto winSize = CCDirector::sharedDirector()->getWinSize();
    float x = Mod::get()->getSavedValue<float>("ball-x", winSize.width - 40.f);
    float y = Mod::get()->getSavedValue<float>("ball-y", winSize.height / 2);
    this->setPosition({std::clamp(x, 26.f, winSize.width - 26.f), std::clamp(y, 26.f, winSize.height - 26.f)});
    refreshScale();

    this->schedule(schedule_selector(GalaxyBall::tick), 0.1f);
    return true;
}

void GalaxyBall::refreshScale() {
    this->setScale(galaxy::state().ballScale);
}

void GalaxyBall::tick(float) {
    galaxy::tick();
    // hide the ball while in a level if the player wants that
    bool hide = inLevel() && !galaxy::state().ballInLevel;
    this->setVisible(!hide);
}

bool GalaxyBall::ccTouchBegan(CCTouch* touch, CCEvent*) {
    if (!getParent() || !isVisible()) return false;
    auto p = getParent()->convertToNodeSpace(touch->getLocation());
    auto c = getPosition();
    float dx = p.x - c.x, dy = p.y - c.y;
    float r = 30.f * getScale();
    if (dx * dx + dy * dy > r * r) return false;
    m_touching = true;
    m_moved = false;
    m_start = p;
    return true;
}

void GalaxyBall::ccTouchMoved(CCTouch* touch, CCEvent*) {
    if (!m_touching || !getParent()) return;
    auto now = getParent()->convertToNodeSpace(touch->getLocation());
    auto prev = getParent()->convertToNodeSpace(touch->getPreviousLocation());
    float dx = now.x - m_start.x, dy = now.y - m_start.y;
    if (dx * dx + dy * dy > 64.f) m_moved = true;
    if (!m_moved) return;
    auto winSize = CCDirector::sharedDirector()->getWinSize();
    auto pos = getPosition() + (now - prev);
    pos.x = std::clamp(pos.x, 26.f, winSize.width - 26.f);
    pos.y = std::clamp(pos.y, 26.f, winSize.height - 26.f);
    setPosition(pos);
}

void GalaxyBall::ccTouchEnded(CCTouch*, CCEvent*) {
    if (!m_touching) return;
    m_touching = false;
    if (m_moved) {
        Mod::get()->setSavedValue<float>("ball-x", getPositionX());
        Mod::get()->setSavedValue<float>("ball-y", getPositionY());
        return;
    }
    galaxy::toggleMenu();
}

void GalaxyBall::ccTouchCancelled(CCTouch* t, CCEvent* e) { ccTouchEnded(t, e); }

// ================================================================
// Menu
// ================================================================

GalaxyMenu* GalaxyMenu::current() { return g_menu; }

GalaxyMenu* GalaxyMenu::create() {
    auto ret = new GalaxyMenu();
    if (ret && ret->init()) {
        ret->autorelease();
        return ret;
    }
    delete ret;
    return nullptr;
}

GalaxyMenu::~GalaxyMenu() {
    if (g_menu == this) g_menu = nullptr;
}

bool GalaxyMenu::init() {
    if (!CCLayer::init()) return false;
    g_menu = this;

    this->setContentSize({kW, kH});
    this->setTouchMode(kCCTouchesOneByOne);
    this->setTouchPriority(-127); // just behind the buttons
    this->setTouchEnabled(true);

    auto winSize = CCDirector::sharedDirector()->getWinSize();
    float scale = galaxy::state().menuScale;
    this->setScale(scale);
    float x = Mod::get()->getSavedValue<float>("menu-x", winSize.width / 2 - kW * scale / 2);
    float y = Mod::get()->getSavedValue<float>("menu-y", winSize.height / 2 - kH * scale / 2);
    this->setPosition({x, y});

    // panel
    m_bg = CCScale9Sprite::create("GJ_square02.png");
    m_bg->setContentSize({kW, kH});
    m_bg->setPosition({kW / 2, kH / 2});
    m_bg->setOpacity(245);
    this->addChild(m_bg);

    // twinkling stars (text, so they work with any texture pack)
    std::mt19937 rng{12345};
    for (int i = 0; i < 26; i++) {
        float sx = 14 + (rng() % static_cast<unsigned>(kW - 28));
        float sy = 14 + (rng() % static_cast<unsigned>(kH - 28));
        auto* star = CCLabelBMFont::create(i % 4 == 0 ? "*" : ".", "chatFont.fnt");
        star->setPosition({sx, sy});
        star->setScale(0.5f + (rng() % 5) * 0.12f);
        star->setOpacity(60 + rng() % 120);
        float d = 0.6f + (rng() % 10) * 0.18f;
        star->runAction(CCRepeatForever::create(CCSequence::create(
            CCFadeTo::create(d, 40), CCFadeTo::create(d, 230), nullptr)));
        this->addChild(star, 1);
    }

    m_title = CCLabelBMFont::create("THE GALAXY", "goldFont.fnt");
    m_title->setScale(0.75f);
    m_title->setPosition({kW / 2, kH - 20});
    this->addChild(m_title, 3);

    auto* menu = CCMenu::create();
    menu->setPosition({0, 0});
    this->addChild(menu, 6);

    // close
    auto* closeSpr = CCSprite::createWithSpriteFrameName("GJ_closeBtn_001.png");
    closeSpr->setScale(0.6f);
    auto* closeBtn = CCMenuItemSpriteExtra::create(closeSpr, this, menu_selector(GalaxyMenu::onClose));
    closeBtn->setPosition({kW - 16, kH - 16});
    menu->addChild(closeBtn);

    // resize buttons
    for (int i = 0; i < 2; i++) {
        auto* spr = ButtonSprite::create(i == 0 ? "-" : "+", "bigFont.fnt", "GJ_button_04.png", 0.5f);
        auto* btn = CCMenuItemSpriteExtra::create(spr, this,
            i == 0 ? menu_selector(GalaxyMenu::onSmaller) : menu_selector(GalaxyMenu::onBigger));
        btn->setPosition({26.f + i * 34.f, kH - 18});
        menu->addChild(btn);
    }

    // tabs
    char const* names[6] = {"Global", "Player", "Build", "Audio", "Style", "Shop"};
    for (int i = 0; i < 6; i++) {
        auto* spr = ButtonSprite::create(names[i], "bigFont.fnt", "GJ_button_04.png", 0.4f);
        auto* btn = CCMenuItemSpriteExtra::create(spr, this, menu_selector(GalaxyMenu::onTab));
        btn->setTag(i);
        btn->setPosition({50.f + i * 56.f, kH - 52});
        menu->addChild(btn);
    }

    m_content = CCNode::create();
    this->addChild(m_content, 4);
    applyTheme();
    buildTab();
    return true;
}

void GalaxyMenu::applyTheme() {
    auto const& t = kThemes[galaxy::state().theme];
    m_bg->setColor(t.panel);
    m_title->setColor(t.accent);
}

void GalaxyMenu::onClose(CCObject*) { this->removeFromParentAndCleanup(true); }

void GalaxyMenu::onBigger(CCObject*) {
    auto& s = galaxy::state();
    s.menuScale = std::clamp(s.menuScale + 0.1f, 0.5f, 1.4f);
    this->setScale(s.menuScale);
    galaxy::save();
}

void GalaxyMenu::onSmaller(CCObject*) {
    auto& s = galaxy::state();
    s.menuScale = std::clamp(s.menuScale - 0.1f, 0.5f, 1.4f);
    this->setScale(s.menuScale);
    galaxy::save();
}

void GalaxyMenu::onTab(CCObject* sender) {
    m_tab = static_cast<CCNode*>(sender)->getTag();
    buildTab();
}

void GalaxyMenu::addToggleRow(char const* name, int featureId, bool value, float y) {
    auto* menu = CCMenu::create();
    menu->setPosition({0, 0});
    m_content->addChild(menu);

    auto* label = CCLabelBMFont::create(name, "bigFont.fnt");
    label->setAnchorPoint({0, 0.5f});
    label->setScale(0.45f);
    label->setPosition({24, y});
    m_content->addChild(label);

    auto* toggle = CCMenuItemToggler::createWithStandardSprites(
        this, menu_selector(GalaxyMenu::onToggle), 0.55f);
    toggle->toggle(value);
    toggle->setTag(featureId);
    toggle->setPosition({kW - 80, y});
    menu->addChild(toggle);

    auto* infoSpr = CCSprite::createWithSpriteFrameName("GJ_infoIcon_001.png");
    infoSpr->setScale(0.6f);
    auto* infoBtn = CCMenuItemSpriteExtra::create(infoSpr, this, menu_selector(GalaxyMenu::onInfo));
    infoBtn->setTag(featureId);
    infoBtn->setPosition({kW - 36, y});
    menu->addChild(infoBtn);
}

// a "<  text  >" row. Tag -1 = left, +1 = right
void GalaxyMenu::addStepper(CCLabelBMFont*& label, float y, SEL_MenuHandler handler) {
    auto* menu = CCMenu::create();
    menu->setPosition({0, 0});
    m_content->addChild(menu);

    label = CCLabelBMFont::create("", "goldFont.fnt");
    label->setScale(0.5f);
    label->setPosition({kW / 2, y});
    m_content->addChild(label);

    for (int i = 0; i < 2; i++) {
        auto* spr = ButtonSprite::create(i == 0 ? "<" : ">", "goldFont.fnt", "GJ_button_01.png", 0.5f);
        auto* btn = CCMenuItemSpriteExtra::create(spr, this, handler);
        btn->setTag(i == 0 ? -1 : 1);
        btn->setPosition({kW / 2 + (i == 0 ? -105.f : 105.f), y});
        menu->addChild(btn);
    }
}

void GalaxyMenu::buildTab() {
    m_content->removeAllChildrenWithCleanup(true);
    m_speedLabel = m_fpsLabel = m_diamondLabel = nullptr;
    m_themeLabel = m_bgLabel = m_ballLabel = nullptr;
    m_amountInput = nullptr;

    auto& s = galaxy::state();
    float top = kH - 90;
    auto const& accent = kThemes[s.theme].accent;

    auto note = [&](char const* text, float y) {
        auto* n = CCLabelBMFont::create(text, "chatFont.fnt");
        n->setScale(0.5f);
        n->setColor(accent);
        n->setPosition({kW / 2, y});
        m_content->addChild(n);
    };

    if (m_tab == 0) { // Global
        addToggleRow("Speedhack", F_SPEED, s.speedOn, top);
        addStepper(m_speedLabel, top - 26, menu_selector(GalaxyMenu::onSpeedStep));
        addToggleRow("FPS Bypass", F_FPS, s.fpsOn, top - 60);
        addStepper(m_fpsLabel, top - 86, menu_selector(GalaxyMenu::onFpsStep));
        addToggleRow("Show FPS", F_SHOWFPS, s.showFps, top - 120);
        m_speedLabel->setString(fmt::format("Speed: {:.2f}x", s.speed).c_str());
        m_fpsLabel->setString(fmt::format("FPS: {}", s.fps).c_str());
    } else if (m_tab == 1) { // Player
        addToggleRow("Noclip", F_NOCLIP, s.noclip, top);
        addToggleRow("No Death Effect", F_NODEATH, s.noDeathEffect, top - 36);
        addToggleRow("No Camera Shake", F_NOSHAKE, s.noShake, top - 72);
        note("Use these inside a level", top - 108);
    } else if (m_tab == 2) { // Build (creator)
        auto* menu = CCMenu::create();
        menu->setPosition({0, 0});
        m_content->addChild(menu);

        auto* gridSpr = ButtonSprite::create("Toggle Grid", "goldFont.fnt", "GJ_button_01.png", 0.6f);
        auto* gridBtn = CCMenuItemSpriteExtra::create(gridSpr, this, menu_selector(GalaxyMenu::onGrid));
        gridBtn->setPosition({kW / 2, top - 6});
        menu->addChild(gridBtn);

        auto* copySpr = ButtonSprite::create("Copy Level Data", "goldFont.fnt", "GJ_button_02.png", 0.6f);
        auto* copyBtn = CCMenuItemSpriteExtra::create(copySpr, this, menu_selector(GalaxyMenu::onCopyLevel));
        copyBtn->setPosition({kW / 2, top - 52});
        menu->addChild(copyBtn);

        note("Open a level in the editor, then tap the ball", top - 92);
        note("Copy Level Data = backup of your level on the clipboard", top - 110);
    } else if (m_tab == 3) { // Audio
        addToggleRow("Audio Sync", F_AUDIO, s.audioSync, top);
        note("Pitch follows your Speedhack speed", top - 36);
        note("Turn Speedhack on in the Global tab", top - 54);
    } else if (m_tab == 4) { // Style
        addStepper(m_themeLabel, top, menu_selector(GalaxyMenu::onThemeStep));
        m_themeLabel->setString(fmt::format("Menu: {}", galaxy::themeName(s.theme)).c_str());
        addStepper(m_bgLabel, top - 36, menu_selector(GalaxyMenu::onBgStep));
        m_bgLabel->setString(fmt::format("Background: {}", galaxy::backgroundName(s.background)).c_str());
        addStepper(m_ballLabel, top - 72, menu_selector(GalaxyMenu::onBallStep));
        m_ballLabel->setString(fmt::format("Ball size: {:.1f}", s.ballScale).c_str());
        addToggleRow("Ball In Level", F_BALLLEVEL, s.ballInLevel, top - 108);
        note("Background changes the main menu", top - 134);
    } else { // Shop / cosmetics
        addToggleRow("Unlock All", F_UNLOCK, s.unlockAll, top);

        m_diamondLabel = CCLabelBMFont::create("", "goldFont.fnt");
        m_diamondLabel->setScale(0.6f);
        m_diamondLabel->setPosition({kW / 2, top - 32});
        m_content->addChild(m_diamondLabel);

        auto* menu = CCMenu::create();
        menu->setPosition({0, 0});
        m_content->addChild(menu);

        int amounts[3] = {100, 1000, 10000};
        for (int i = 0; i < 3; i++) {
            auto* spr = ButtonSprite::create(("+" + std::to_string(amounts[i])).c_str(),
                                             "goldFont.fnt", "GJ_button_01.png", 0.55f);
            auto* btn = CCMenuItemSpriteExtra::create(spr, this, menu_selector(GalaxyMenu::onAddDiamonds));
            btn->setTag(amounts[i]);
            btn->setPosition({kW / 2 - 90.f + i * 90.f, top - 66});
            menu->addChild(btn);
        }

        m_amountInput = geode::TextInput::create(120, "Any amount", "bigFont.fnt");
        m_amountInput->setCommonFilter(geode::CommonFilter::Uint);
        m_amountInput->setMaxCharCount(9);
        m_amountInput->setScale(0.8f);
        m_amountInput->setPosition({kW / 2 - 45, top - 102});
        m_content->addChild(m_amountInput);

        auto* addSpr = ButtonSprite::create("Add", "goldFont.fnt", "GJ_button_02.png", 0.55f);
        auto* addBtn = CCMenuItemSpriteExtra::create(addSpr, this, menu_selector(GalaxyMenu::onAddCustom));
        addBtn->setPosition({kW / 2 + 70, top - 102});
        menu->addChild(addBtn);

        auto* warn = CCLabelBMFont::create("1% chance you get caught!", "chatFont.fnt");
        warn->setScale(0.5f);
        warn->setColor({255, 120, 120});
        warn->setPosition({kW / 2, top - 128});
        m_content->addChild(warn);

        refreshDiamonds();
    }
}

void GalaxyMenu::refreshDiamonds() {
    if (!m_diamondLabel) return;
    int have = 0;
    if (auto* gsm = GameStatsManager::sharedState()) have = gsm->getStat("13");
    m_diamondLabel->setString(fmt::format("Diamonds: {}", have).c_str());
}

void GalaxyMenu::onToggle(CCObject* sender) {
    auto* toggle = static_cast<CCMenuItemToggler*>(sender);
    bool nowOn = !toggle->isToggled(); // the toggler flips after the callback
    auto& s = galaxy::state();
    switch (toggle->getTag()) {
        case F_SPEED: s.speedOn = nowOn; break;
        case F_SHOWFPS: s.showFps = nowOn; break;
        case F_FPS: s.fpsOn = nowOn; break;
        case F_NOCLIP: s.noclip = nowOn; break;
        case F_AUDIO: s.audioSync = nowOn; break;
        case F_UNLOCK: s.unlockAll = nowOn; break;
        case F_NODEATH: s.noDeathEffect = nowOn; break;
        case F_NOSHAKE: s.noShake = nowOn; break;
        case F_BALLLEVEL: s.ballInLevel = nowOn; break;
    }
    galaxy::save();
    galaxy::apply();
}

void GalaxyMenu::onInfo(CCObject* sender) {
    int id = static_cast<CCNode*>(sender)->getTag();
    FLAlertLayer::create("Info", featureInfo(id), "OK")->show();
}

void GalaxyMenu::onSpeedStep(CCObject* sender) {
    auto& s = galaxy::state();
    int dir = static_cast<CCNode*>(sender)->getTag();
    s.speed = std::clamp(std::round((s.speed + dir * 0.1f) * 100.f) / 100.f, 0.1f, 10.f);
    if (m_speedLabel) m_speedLabel->setString(fmt::format("Speed: {:.2f}x", s.speed).c_str());
    galaxy::save();
    galaxy::apply();
}

void GalaxyMenu::onFpsStep(CCObject* sender) {
    auto& s = galaxy::state();
    s.fps = std::clamp(s.fps + 30 * static_cast<CCNode*>(sender)->getTag(), 30, 1000);
    if (m_fpsLabel) m_fpsLabel->setString(fmt::format("FPS: {}", s.fps).c_str());
    galaxy::save();
    galaxy::apply();
}

void GalaxyMenu::onThemeStep(CCObject* sender) {
    auto& s = galaxy::state();
    int n = galaxy::themeCount();
    s.theme = (s.theme + static_cast<CCNode*>(sender)->getTag() + n) % n;
    if (m_themeLabel) m_themeLabel->setString(fmt::format("Menu: {}", galaxy::themeName(s.theme)).c_str());
    applyTheme();
    galaxy::save();
}

void GalaxyMenu::onBgStep(CCObject* sender) {
    auto& s = galaxy::state();
    int n = galaxy::backgroundCount();
    s.background = (s.background + static_cast<CCNode*>(sender)->getTag() + n) % n;
    if (m_bgLabel) m_bgLabel->setString(fmt::format("Background: {}", galaxy::backgroundName(s.background)).c_str());
    galaxy::save();
    galaxy::applyBackground();
}

void GalaxyMenu::onBallStep(CCObject* sender) {
    auto& s = galaxy::state();
    s.ballScale = std::clamp(std::round((s.ballScale + 0.1f * static_cast<CCNode*>(sender)->getTag()) * 10.f) / 10.f, 0.6f, 2.0f);
    if (m_ballLabel) m_ballLabel->setString(fmt::format("Ball size: {:.1f}", s.ballScale).c_str());
    if (g_ball) g_ball->refreshScale();
    galaxy::save();
}

void GalaxyMenu::onGrid(CCObject*) {
    auto* editor = LevelEditorLayer::get();
    if (!editor) {
        Notification::create("Open a level in the editor first", NotificationIcon::Warning)->show();
        return;
    }
    editor->toggleGrid(!editor->m_showGrid);
}

void GalaxyMenu::onCopyLevel(CCObject*) {
    auto* editor = LevelEditorLayer::get();
    if (!editor) {
        Notification::create("Open a level in the editor first", NotificationIcon::Warning)->show();
        return;
    }
    geode::utils::clipboard::write(std::string(editor->getLevelString()));
    Notification::create("Level data copied", NotificationIcon::Success)->show();
}

void GalaxyMenu::onAddDiamonds(CCObject* sender) {
    galaxy::addDiamonds(static_cast<CCNode*>(sender)->getTag());
    refreshDiamonds();
}

void GalaxyMenu::onAddCustom(CCObject*) {
    if (!m_amountInput) return;
    std::string text = m_amountInput->getString();
    if (text.empty()) {
        Notification::create("Type an amount first", NotificationIcon::Warning)->show();
        return;
    }
    long long amount = 0;
    try { amount = std::stoll(text); } catch (...) { amount = 0; }
    amount = std::min<long long>(amount, 1000000000LL);
    galaxy::addDiamonds(static_cast<int>(amount));
    refreshDiamonds();
}

// ---- dragging the menu ---------------------------------------

bool GalaxyMenu::ccTouchBegan(CCTouch* touch, CCEvent*) {
    auto local = this->convertToNodeSpace(touch->getLocation());
    m_dragging = CCRect(0, 0, kW, kH).containsPoint(local);
    return m_dragging;
}

void GalaxyMenu::ccTouchMoved(CCTouch* touch, CCEvent*) {
    if (!m_dragging || !getParent()) return;
    auto now = getParent()->convertToNodeSpace(touch->getLocation());
    auto prev = getParent()->convertToNodeSpace(touch->getPreviousLocation());
    setPosition(getPosition() + (now - prev));
}

void GalaxyMenu::ccTouchEnded(CCTouch*, CCEvent*) {
    if (!m_dragging) return;
    m_dragging = false;
    Mod::get()->setSavedValue<float>("menu-x", getPositionX());
    Mod::get()->setSavedValue<float>("menu-y", getPositionY());
}

void GalaxyMenu::ccTouchCancelled(CCTouch* t, CCEvent* e) { ccTouchEnded(t, e); }
