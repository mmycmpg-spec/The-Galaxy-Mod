#pragma once
#include <Geode/Geode.hpp>
#include <Geode/ui/TextInput.hpp>

using namespace geode::prelude;

namespace galaxy {
    struct State {
        bool speedOn = false;
        float speed = 1.f;
        bool audioSync = false;
        bool fpsOn = false;
        int fps = 60;
        bool showFps = false;
        bool noclip = false;
        bool unlockAll = false;
        bool diamondsLocked = false; // set by the 1% "caught" event, per session
    };

    State& state();
    void load();
    void save();
    void apply();      // speed, fps, show fps
    void tickAudio();  // keeps music/sfx pitch in sync with speed
    void addDiamonds(int amount);
    void ensureBall(); // creates the floating ball once
}

// Draggable menu with tabs
class GalaxyMenu : public CCLayer {
public:
    static GalaxyMenu* create();
    static GalaxyMenu* current();
    bool init();
    ~GalaxyMenu() override;

    bool ccTouchBegan(CCTouch*, CCEvent*) override;
    void ccTouchMoved(CCTouch*, CCEvent*) override;
    void ccTouchEnded(CCTouch*, CCEvent*) override;
    void ccTouchCancelled(CCTouch*, CCEvent*) override;

    static constexpr float kW = 300.f;
    static constexpr float kH = 230.f;

private:
    CCNode* m_content = nullptr;
    CCLabelBMFont* m_valueLabel = nullptr;
    CCLabelBMFont* m_speedLabel = nullptr;
    CCLabelBMFont* m_fpsLabel = nullptr;
    CCLabelBMFont* m_diamondLabel = nullptr;
    geode::TextInput* m_amountInput = nullptr;
    int m_tab = 0;
    bool m_dragging = false;

    void buildTab();
    void addToggleRow(char const* name, int featureId, bool value, float y);
    void onTab(CCObject*);
    void onToggle(CCObject*);
    void onInfo(CCObject*);
    void onSpeedStep(CCObject*);
    void onFpsStep(CCObject*);
    void onAddDiamonds(CCObject*);
    void onAddCustom(CCObject*);
    void onClose(CCObject*);
    void refreshDiamonds();
};

// The floating ball
class GalaxyBall : public CCLayer {
public:
    static GalaxyBall* create();
    bool init();

    bool ccTouchBegan(CCTouch*, CCEvent*) override;
    void ccTouchMoved(CCTouch*, CCEvent*) override;
    void ccTouchEnded(CCTouch*, CCEvent*) override;
    void ccTouchCancelled(CCTouch*, CCEvent*) override;

private:
    bool m_touching = false;
    bool m_moved = false;
    CCPoint m_start;
    void tick(float dt);
};
