#pragma once
#include <Geode/Geode.hpp>
#include <Geode/ui/TextInput.hpp>

using namespace geode::prelude;

namespace galaxy {
    struct State {
        bool speedOn = false;
        float speed = 1.f;
        bool audioSync = false;
        bool fpsOn = false;
        int fps = 60;
        bool showFps = false;
        bool noclip = false;
        bool noDeathEffect = false;
        bool noShake = false;
        bool unlockAll = false;
        bool ballInLevel = true;
        int theme = 0;       // menu color theme
        int background = 0;  // main menu background preset
        float ballScale = 1.f;
        float menuScale = 0.85f;
        bool diamondsLocked = false; // set by the 1% "caught" event, per session
    };

    State& state();
    void load();
    void save();
    void apply();           // speed, fps, show fps
    void applyBackground(); // main menu background color
    void tick();            // keeps pitch / fps in sync
    void addDiamonds(int amount);
    void ensureBall();      // creates the floating ball once
    void toggleMenu();      // opens or closes the Galaxy menu

    int themeCount();
    char const* themeName(int i);
    int backgroundCount();
    char const* backgroundName(int i);
}

// Draggable, resizable, themed menu with tabs
class GalaxyMenu : public CCLayer {
public:
    static GalaxyMenu* create();
    static GalaxyMenu* current();
    bool init();
    ~GalaxyMenu() override;

    bool ccTouchBegan(CCTouch*, CCEvent*) override;
    void ccTouchMoved(CCTouch*, CCEvent*) override;
    void ccTouchEnded(CCTouch*, CCEvent*) override;
    void ccTouchCancelled(CCTouch*, CCEvent*) override;

    static constexpr float kW = 380.f;
    static constexpr float kH = 265.f;

private:
    CCNode* m_content = nullptr;
    CCNode* m_frame = nullptr;
    CCLabelBMFont* m_speedLabel = nullptr;
    CCLabelBMFont* m_fpsLabel = nullptr;
    CCLabelBMFont* m_diamondLabel = nullptr;
    CCLabelBMFont* m_themeLabel = nullptr;
    CCLabelBMFont* m_bgLabel = nullptr;
    CCLabelBMFont* m_ballLabel = nullptr;
    CCLabelBMFont* m_title = nullptr;
    CCScale9Sprite* m_bg = nullptr;
    geode::TextInput* m_amountInput = nullptr;
    int m_tab = 0;
    bool m_dragging = false;

    void buildTab();
    void applyTheme();
    void addToggleRow(char const* name, int featureId, bool value, float y);
    void addStepper(CCLabelBMFont*& label, float y, SEL_MenuHandler handler);
    void onTab(CCObject*);
    void onToggle(CCObject*);
    void onInfo(CCObject*);
    void onSpeedStep(CCObject*);
    void onFpsStep(CCObject*);
    void onThemeStep(CCObject*);
    void onBgStep(CCObject*);
    void onBallStep(CCObject*);
    void onAddDiamonds(CCObject*);
    void onAddCustom(CCObject*);
    void onGrid(CCObject*);
    void onCopyLevel(CCObject*);
    void onBigger(CCObject*);
    void onSmaller(CCObject*);
    void onClose(CCObject*);
    void refreshDiamonds();
};

// The floating ball
class GalaxyBall : public CCLayer {
public:
    static GalaxyBall* create();
    bool init();
    void refreshScale();

    bool ccTouchBegan(CCTouch*, CCEvent*) override;
    void ccTouchMoved(CCTouch*, CCEvent*) override;
    void ccTouchEnded(CCTouch*, CCEvent*) override;
    void ccTouchCancelled(CCTouch*, CCEvent*) override;

private:
    bool m_touching = false;
    bool m_moved = false;
    CCPoint m_start;
    CCNode* m_icon = nullptr;
    void tick(float dt);
};
