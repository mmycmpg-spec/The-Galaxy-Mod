#include "Galaxy.hpp"
#include <Geode/modify/MenuLayer.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/modify/PauseLayer.hpp>
#include <Geode/modify/EditorPauseLayer.hpp>
#include <Geode/modify/GameManager.hpp>
#include <Geode/modify/PlayerObject.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>

// Create the floating ball, apply saved settings and the menu background
class $modify(GalaxyMenuLayer, MenuLayer) {
    bool init() {
        if (!MenuLayer::init()) return false;
        galaxy::ensureBall();
        galaxy::apply();
        galaxy::applyBackground();
        return true;
    }
};

// Noclip
class $modify(GalaxyPlayLayer, PlayLayer) {
    void destroyPlayer(PlayerObject* player, GameObject* object) {
        if (galaxy::state().noclip && object != m_anticheatSpike) return;
        PlayLayer::destroyPlayer(player, object);
    }
};

// No death effect
class $modify(GalaxyPlayerObject, PlayerObject) {
    void playDeathEffect() {
        if (galaxy::state().noDeathEffect) return;
        PlayerObject::playDeathEffect();
    }
};

// No camera shake
class $modify(GalaxyBaseGameLayer, GJBaseGameLayer) {
    void shakeCamera(float duration, float strength, float interval) {
        if (galaxy::state().noShake) return;
        GJBaseGameLayer::shakeCamera(duration, strength, interval);
    }

    // Speedhack: the game sets its time scale here (time warp), so multiply our speed in
    void applyTimeWarp(float timeWarp) {
        auto& s = galaxy::state();
        if (s.speedOn) timeWarp *= s.speed;
        GJBaseGameLayer::applyTimeWarp(timeWarp);
    }
};

// Unlock all cosmetics (shows everything as unlocked on this device)
class $modify(GalaxyGameManager, GameManager) {
    bool isIconUnlocked(int id, IconType type) {
        if (galaxy::state().unlockAll) return true;
        return GameManager::isIconUnlocked(id, type);
    }
    bool isColorUnlocked(int id, UnlockType type) {
        if (galaxy::state().unlockAll) return true;
        return GameManager::isColorUnlocked(id, type);
    }
};

// "Galaxy" button in the pause menu (so you can open the menu even if the ball is hidden)
class $modify(GalaxyPauseLayer, PauseLayer) {
    void customSetup() {
        PauseLayer::customSetup();
        auto winSize = CCDirector::sharedDirector()->getWinSize();
        auto* menu = CCMenu::create();
        menu->setPosition({0, 0});
        auto* spr = ButtonSprite::create("Galaxy", "goldFont.fnt", "GJ_button_01.png", 0.6f);
        auto* btn = CCMenuItemSpriteExtra::create(spr, this, menu_selector(GalaxyPauseLayer::onGalaxy));
        btn->setPosition({60.f, winSize.height - 28.f});
        menu->addChild(btn);
        this->addChild(menu, 100);
    }
    void onGalaxy(CCObject*) { galaxy::toggleMenu(); }
};

// ...and in the editor pause menu
class $modify(GalaxyEditorPauseLayer, EditorPauseLayer) {
    void customSetup() {
        EditorPauseLayer::customSetup();
        auto winSize = CCDirector::sharedDirector()->getWinSize();
        auto* menu = CCMenu::create();
        menu->setPosition({0, 0});
        auto* spr = ButtonSprite::create("Galaxy", "goldFont.fnt", "GJ_button_01.png", 0.6f);
        auto* btn = CCMenuItemSpriteExtra::create(spr, this, menu_selector(GalaxyEditorPauseLayer::onGalaxy));
        btn->setPosition({60.f, winSize.height - 28.f});
        menu->addChild(btn);
        this->addChild(menu, 100);
    }
    void onGalaxy(CCObject*) { galaxy::toggleMenu(); }
};
