#include "Galaxy.hpp"
#include <Geode/modify/MenuLayer.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/modify/GameManager.hpp>

// Create the floating ball and apply saved settings when the main menu shows up
class $modify(GalaxyMenuLayer, MenuLayer) {
    bool init() {
        if (!MenuLayer::init()) return false;
        galaxy::ensureBall();
        galaxy::apply();
        return true;
    }
};

// Noclip
class $modify(GalaxyPlayLayer, PlayLayer) {
    void destroyPlayer(PlayerObject* player, GameObject* object) {
        if (galaxy::state().noclip && object != m_anticheatSpike) return;
        PlayLayer::destroyPlayer(player, object);
    }
};

// Unlock all cosmetics (shows everything as unlocked on this device)
class $modify(GalaxyGameManager, GameManager) {
    bool isIconUnlocked(int id, IconType type) {
        if (galaxy::state().unlockAll) return true;
        return GameManager::isIconUnlocked(id, type);
    }
    bool isColorUnlocked(int id, UnlockType type) {
        if (galaxy::state().unlockAll) return true;
        return GameManager::isColorUnlocked(id, type);
    }
};
