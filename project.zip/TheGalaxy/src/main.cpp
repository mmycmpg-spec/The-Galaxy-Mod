#include <Geode/Geode.hpp>
#include "Galaxy.hpp"

using namespace geode::prelude;

$on_mod(Loaded) {
    galaxy::load();
    log::info("The Galaxy loaded");
}
